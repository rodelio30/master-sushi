<?php
include 'header.php';


// Assume user is logged in
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: ../include/signout.php");
    exit();
}

$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';

// Clear messages after displaying
unset($_SESSION['success'], $_SESSION['error']);

// Handle update request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact_number = $_POST['contact_number'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE users SET first_name=?, last_name=?, username=?, email=?, contact_number=?, address=? WHERE user_id=?");
    $stmt->bind_param("ssssssi", $first_name, $last_name, $username, $email, $contact_number, $address, $user_id);

    if ($stmt->execute()) {
      $_SESSION['success'] = "Profile updated successfully!";
      header("Location: settings.php"); // reload with redirect
      exit();
  } else {
      $_SESSION['error'] = "Failed to update profile.";
      header("Location: settings.php");
      exit();
  }
}

// Fetch current user data
$stmt = $conn->prepare("SELECT * FROM users WHERE user_id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>  

<style>

#productSection {
min-height: 100vh;
/* background-color: #fff; */
background: url('../assets/img/bg-cta.png') no-repeat center center/cover;
border-radius: 12px;
box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
padding: 2rem 8rem;
box-sizing: border-box;
}

.card {
  padding: 2rem;
}
  
  </style>
<body>

<?php
$nav_active = "";
include 'nav.php';
?>  
  
<section id="productSection">
  <div class="container">
    <!-- Main Content -->
    <div class="mt-2">
        <h2 style="margin-left: 1rem; margin-bottom: 20px; font-weight: bold;">Settings</h2>
              <div class="card">
        <div class="card-body">
                  <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

  <form method="POST">
    <div class="row mb-3">
      <div class="col-md-6">
        <label>First Name</label>
        <input type="text" name="first_name" class="form-control" value="<?= htmlspecialchars($user['first_name']) ?>" required>
      </div>
      <div class="col-md-6">
        <label>Last Name</label>
        <input type="text" name="last_name" class="form-control" value="<?= htmlspecialchars($user['last_name']) ?>" required>
      </div>
    </div>

    <div class="mb-3">
      <label>Username</label>
      <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($user['username']) ?>" required>
    </div>

    <div class="mb-3">
      <label>Email</label>
      <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>

    <div class="mb-3">
      <label>Contact Number</label>
      <input type="text" name="contact_number" class="form-control" value="<?= htmlspecialchars($user['contact_number']) ?>">
    </div>

    <div class="mb-3">
      <label>Address</label>
      <textarea name="address" class="form-control"><?= htmlspecialchars($user['address']) ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>

    </div>
  </div>
  </div>
</section>
<?php include 'footer.php';?>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</html>
